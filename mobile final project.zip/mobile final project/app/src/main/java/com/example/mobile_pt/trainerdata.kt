package com.example.mobile_pt

data class trainerdata(
 val address: String? = null,
 val username: String? = null,
 val uid: String?= null,
val x : Double? =null,
 val y: Double? = null,
var distance : Double? =null
)