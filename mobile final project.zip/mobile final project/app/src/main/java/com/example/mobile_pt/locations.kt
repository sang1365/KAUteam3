package com.example.mobile_pt


data class locations(
    val address: String? = null,
    val profileImageUrl : String? = null,
    val uid : String? = null,
    val username : String? =null,
    val x : Double? = null,
    val y : Double? = null

)